import model.Bookings;
import model.Rate;
import model.Shows;

public class Main {
    public static void main(String[] args) {

        Shows so1 = new Shows("Mahapurush", "Big Movies", "BigMovies", "FCube Cinemas");
        Shows so2 = new Shows("Bhediya", "Big Movies", "One Cinemas", "FCube Cinemas");
        Shows so3 = new Shows("Avatar", "One Cinemas", "BigMovies", "FCube Cinemas");

        so1.getAvailableLocations();
        so2.getAvailableLocations();
        so3.getAvailableLocations();

        Rate rt1 = new Rate(350, 500, so1.getMovie());
        Rate rt2 = new Rate(300, 500, so2.getMovie());
        Rate rt3 = new Rate(350, 500, so3.getMovie());

        rt1.getAvailableRates();
        rt2.getAvailableRates();
        rt3.getAvailableRates();

        Bookings bk1 = new Bookings(4, so1.getLocation2(), true, rt1.getPremium(), so1.getMovie());
        Bookings bk2 = new Bookings(2, so2.getLocation3(), false, rt2.getPrice(), so2.getMovie());
        Bookings bk3 = new Bookings(6, so3.getLocation1(), true, rt3.getPrice(), so3.getMovie());

        bk1.getTotal();
        bk2.getTotal();
        bk3.getTotal();
    }
}